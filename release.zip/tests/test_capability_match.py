from __future__ import annotations

import asyncio
import json
import sqlite3
import uuid
from pathlib import Path
from types import SimpleNamespace

import pytest
from starlette.requests import Request

from ecs.app import auth, config, database
from ecs.app.gateway import gateway
from ecs.app.routes.capability_match import (
    AnalyzeScenarioRequest,
    CreateDraftStubRequest,
    OrganizeCapabilitiesRequest,
    _analysis_tasks,
    admin_capabilities_page,
    analysis_limiter,
    analyze_capability_match,
    capability_gap_analytics,
    capability_match_page,
    capability_catalog_job,
    capability_source_changes,
    create_gap_stub,
    export_capability_match,
    get_capability_match,
    start_capability_catalog_organization,
)
from ecs.app.routes import capability_match as capability_match_routes
from worker.capability_matcher import (
    R_AND_D_CLASSIFICATION,
    enforce_abstraction_hard_gate,
    retrieve_relevant_capability_evidence,
)
from worker import capability_matcher
from worker.manager import WorkerManager


def _worker_payload(
    *,
    capability_level: str = "L0_primitive_driver",
    capability_type: str | None = None,
    verified_operational_profile: bool = False,
) -> dict:
    return {
        "scenario_spec": {
            "scenario_id": "SCN-POPCORN",
            "title": "Popcorn booth",
            "business_goal": "Serve popcorn safely",
            "target": "Popcorn cup filling",
            "environment": "Outdoor park",
            "payload": "Less than 1.5 kg",
            "throughput": "15 cups per minute",
            "assumptions": [],
            "unknowns": ["Ambient lighting range"],
        },
        "atomic_requirements": [
            {
                "requirement_id": "REQ-FILL",
                "name": "Fill popcorn cup",
                "required_capability_type": "operational_behavior",
                "effect": "Fill one cup to a bounded amount",
                "acceptance_criteria": ["Target mass tolerance is met"],
                "constraints": ["Food-safe contact surfaces"],
                "dependencies": [],
            }
        ],
        "capabilities": [
            {
                "capability_id": "CAP-JOINT",
                "name": "Set joint angle",
                **({"capability_type": capability_type} if capability_type else {"abstraction_level": capability_level}),
                "effect": "Command one joint",
                "status": "draft",
                "evidence_level": "E2",
                "evidence_refs": ["wiki/sources/sdk.md#joint-command"],
                "verification_profiles": ([{
                    "workspace_type": "indoor controlled",
                    "lighting": "normal",
                    "terrain_weather": "level and dry",
                    "workspace_dynamics": "low",
                    "object_payload_boundary": "bounded",
                    "duty_cycle": "bench run",
                    "versions": {},
                    "test_level": "bench",
                    "sample_size": 10,
                    "passed_count": 10,
                    "measured_values": [],
                    "evidence_locator": "wiki/test.md",
                    "support_state": "supported",
                    "limitations": [],
                    "unknowns": [],
                }] if verified_operational_profile else []),
                "migration_warnings": [],
            }
        ],
        "feasibility_assessment": {
            "assessment_id": "ASM-WORKER",
            "scenario_id": "SCN-POPCORN",
            "capability_catalog_revision": "wiki-current",
            "matches": [
                {
                    "match_id": "MATCH-FILL",
                    "requirement_id": "REQ-FILL",
                    "capability_ids": ["CAP-JOINT"],
                    "gates": [
                        {"name": "Evidence", "status": "pass", "hard": True, "basis": "SDK reference"}
                    ],
                    "match_state": "conditional",
                    "confidence": 0.8,
                    "evidence_level": "E2",
                    "conditions": [],
                    "gaps": [],
                    "next_action": "Bench test",
                    "rd_gap": None,
                }
            ],
            "technical_conclusion": "feasible_with_conditions",
            "deployment_conclusion": "viable_with_conditions",
            "deployment_gates": [
                {"name": "Safety", "status": "unknown", "hard": True, "basis": "No field test"}
            ],
            "engineering_effort": {
                "overall_band": "configuration",
                "workstreams": [],
                "dependencies": [],
                "risk_factors": [],
                "evidence_basis": "No gap identified",
                "owners": ["engineering"],
                "smallest_validation_step": "Run a bench test",
            },
            "residual_risks": ["Outdoor lighting"],
            "next_experiment": "Bench filling test",
        },
    }


@pytest.fixture(autouse=True)
def isolated_database(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    monkeypatch.setattr(database, "DATABASE_PATH", tmp_path / "agent_jobs.db")
    database.initialize_database()
    analysis_limiter.history.clear()
    _analysis_tasks.clear()
    gateway.websocket = None
    async def immediate_to_thread(function, /, *args, **kwargs):
        return function(*args, **kwargs)

    monkeypatch.setattr(asyncio, "to_thread", immediate_to_thread)
    yield
    gateway.websocket = None


def _request(*, token: str = "") -> Request:
    headers = []
    if token:
        headers.append(
            (b"cookie", f"{config.SESSION_COOKIE_NAME}={token}".encode("ascii"))
        )
    return Request(
        {
            "type": "http",
            "http_version": "1.1",
            "method": "POST",
            "scheme": "http",
            "path": "/",
            "raw_path": b"/",
            "query_string": b"",
            "headers": headers,
            "client": ("127.0.0.1", 12345),
            "server": ("testserver", 80),
        }
    )


def _admin_request() -> tuple[Request, str]:
    suffix = uuid.uuid4().hex[:8]
    user_id = database.create_user_record(
        username=f"cap_admin_{suffix}",
        email=f"cap_admin_{suffix}@example.com",
        password_hash="hash",
        password_salt="salt",
        role="admin",
        teams="",
    )
    token, csrf = auth.create_login_session(user_id)
    return _request(token=token), csrf


def test_legacy_l0_only_match_is_deterministically_unproven() -> None:
    result = enforce_abstraction_hard_gate(_worker_payload())
    assessment = result["feasibility_assessment"]
    match = assessment["matches"][0]

    assert match["match_state"] == "unproven"
    assert R_AND_D_CLASSIFICATION in match["gaps"]
    assert match["rd_gap"]["effort_band"] == "prototype"
    assert any(gate["name"] == "Operational evidence and contract gate" for gate in match["gates"])
    assert assessment["technical_conclusion"] == "prototype_required"
    assert assessment["deployment_conclusion"] == "business_case_incomplete"
    assert assessment["engineering_effort"]["overall_band"] == "prototype"
    assert result["capabilities"][0]["capability_type"] == "building_block"


def test_supported_operational_behavior_is_not_reclassified_by_evidence_gate() -> None:
    payload = _worker_payload(
        capability_type="operational_behavior", verified_operational_profile=True
    )
    result = enforce_abstraction_hard_gate(payload)
    match = result["feasibility_assessment"]["matches"][0]

    assert match["match_state"] == "conditional"
    assert match["gaps"] == []
    assert match["rd_gap"] is None


def test_hard_gate_failure_cannot_be_compensated_by_model_conclusion() -> None:
    payload = _worker_payload(
        capability_type="operational_behavior", verified_operational_profile=True
    )
    payload["feasibility_assessment"]["matches"][0]["gates"][0].update(
        {"status": "fail", "hard": True}
    )
    payload["feasibility_assessment"]["technical_conclusion"] = "feasible"
    payload["feasibility_assessment"]["deployment_conclusion"] = "viable"
    result = enforce_abstraction_hard_gate(payload)
    assessment = result["feasibility_assessment"]
    assert assessment["technical_conclusion"] == "infeasible"
    assert assessment["deployment_conclusion"] == "not_viable"


def test_relevant_evidence_retrieval_prioritizes_operating_envelope(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(
        capability_matcher,
        "load_model_capability_catalog",
        lambda model_id: [
            {
                "capability_id": "CAP-GENERIC-WALK",
                "name": "Generic walking",
                "capability_type": "building_block",
                "effect": "Walk forward",
                "verification_profiles": [],
            },
            {
                "capability_id": "CAP-LOCKER-RETRIEVAL",
                "name": "Locker parcel retrieval",
                "capability_type": "operational_behavior",
                "effect": "Retrieve a parcel from a locker opening",
                "verification_profiles": [
                    {
                        "workspace_type": "locker aisle",
                        "lighting": "300-500 lux",
                        "object_payload_boundary": "up to 2 kg and 450 mm width",
                        "support_state": "conditional",
                    }
                ],
            },
        ],
    )
    evidence = retrieve_relevant_capability_evidence(
        {
            "initial_intent": "Retrieve a parcel from a locker",
            "objects": [{"normalized_value": "2 kg parcel"}],
        },
        "walker_s2",
        limit=1,
    )
    assert evidence[0]["capability_id"] == "CAP-LOCKER-RETRIEVAL"
    assert evidence[0]["verification_profiles"][0]["lighting"] == "300-500 lux"
    chinese_evidence = retrieve_relevant_capability_evidence(
        {"initial_intent": "从快递柜取出包裹，并确认光照和重量边界"},
        "walker_s2",
        limit=1,
    )
    assert chinese_evidence[0]["capability_id"] == "CAP-LOCKER-RETRIEVAL"
    unrelated = retrieve_relevant_capability_evidence(
        {"initial_intent": "Calibrate an unrelated acoustic sensor"},
        "walker_s2",
        limit=1,
    )
    assert unrelated == []


def test_repository_catalog_loader_never_leaks_capabilities_between_robots(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    catalog = tmp_path / "wiki" / "capabilities"
    catalog.mkdir(parents=True)
    for capability_id, model_id in (
        ("CAP-WS2-ONLY", "walker_s2"),
        ("CAP-WC1-ONLY", "walker_c1"),
        ("CAP-UNASSIGNED", "unassigned"),
    ):
        (catalog / f"{capability_id}.json").write_text(
            json.dumps(
                {
                    "capability_id": capability_id,
                    "capability_type": "building_block",
                    "scope": {"model_id": model_id},
                    "verification_profiles": [],
                    "migration_warnings": [],
                }
            ),
            encoding="utf-8",
        )
    monkeypatch.setattr(
        capability_matcher,
        "get_team_config",
        lambda model_id: SimpleNamespace(base_dir=tmp_path),
    )

    entries = capability_matcher.load_model_capability_catalog("walker_s2")

    assert [entry["capability_id"] for entry in entries] == ["CAP-WS2-ONLY"]


def test_worker_analysis_embeds_policies_and_reapplies_hard_gate(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    captured: dict = {}

    class FakeClient:
        async def complete_json(self, system: str, prompt: str, **kwargs):
            captured.setdefault("calls", []).append((system, prompt, kwargs))
            stage = kwargs["stage"]
            if stage == "scenario requirement extraction":
                payload = _worker_payload()
                return {
                    "scenario_spec": payload["scenario_spec"],
                    "atomic_requirements": payload["atomic_requirements"],
                }
            if stage == "scenario evidence evaluation":
                return _worker_payload()
            return {
                "executive_summary": "Prototype validation is required.",
                "engineering_effort": {"overall_band": "prototype"},
                "tool_support": [],
                "poc_plan": {"smallest_step": "Bench test"},
            }

    monkeypatch.setattr(capability_matcher, "create_deepseek_client", lambda **_kwargs: FakeClient())
    result = asyncio.run(
        capability_matcher.analyze_scenario(
            "Serve popcorn outdoors",
            model_id="walker_s2",
            language="en",
        )
    )

    system_prompt = captured["calls"][0][0]
    assert "Build a `ScenarioSpec`" in system_prompt
    assert "Do not equate an available API" in system_prompt
    assert all("tools" not in call[2] for call in captured["calls"])
    assert result["feasibility_assessment"]["matches"][0]["match_state"] == "unproven"


def test_worker_unwraps_nested_structured_result_and_rejects_incomplete_envelope() -> None:
    payload = _worker_payload()
    nested = capability_matcher._structured_payload(json.dumps({"result": payload}))
    fenced = capability_matcher._structured_payload(
        json.dumps({"result": f"```json\n{json.dumps(payload)}\n```"})
    )

    assert nested == payload
    assert fenced == payload
    with pytest.raises(ValueError, match="no complete structured feasibility result"):
        capability_matcher._structured_payload(
            json.dumps({"type": "result", "result": "Analysis was incomplete"})
        )


def test_worker_capability_analysis_queue_is_bounded() -> None:
    manager = WorkerManager()

    async def fill_queue() -> dict:
        for index in range(manager.capability_match_queue.maxsize):
            await manager.route_message(
                {
                    "type": "analyze_scenario",
                    "id": f"analysis-{index}",
                    "scenario_text": "Scenario",
                    "model_id": "walker_s2",
                }
            )
        await manager.route_message(
            {
                "type": "analyze_scenario",
                "id": "analysis-overflow",
                "scenario_text": "Scenario",
                "model_id": "walker_s2",
            }
        )
        return manager.outgoing.get_nowait()

    rejected = asyncio.run(fill_queue())
    assert rejected["id"] == "analysis-overflow"
    assert rejected["status"] == "failed"


def test_schema_bundle_contains_scenario_v2_contracts_and_capability_contract() -> None:
    schema_root = Path(__file__).resolve().parents[1] / "shared" / "schemas"
    schemas = sorted(schema_root.glob("*.schema.json"))
    assert len(schemas) == 12
    assert {
        "scenario-session.schema.json",
        "clarification-turn.schema.json",
        "analysis-progress-event.schema.json",
        "report-revision.schema.json",
    } <= {path.name for path in schemas}
    capability_schema = json.loads((schema_root / "atomic-capability.schema.json").read_text())
    requirement_schema = json.loads((schema_root / "atomic-requirement.schema.json").read_text())
    assert "capability_type" in capability_schema["required"]
    assert capability_schema["properties"]["capability_type"]["enum"] == ["building_block", "operational_behavior"]
    assert "required_capability_type" in requirement_schema["required"]
    runtime = capability_matcher.MATCHER_RESPONSE_SCHEMA
    scenario_record = runtime["$defs"]["scenario_record"]
    requirement_record = runtime["$defs"]["requirement_record"]
    assert {"boundary", "environment_profile", "operations_profile"} <= set(
        scenario_record["required"]
    )
    assert {"acceptance_criteria", "constraints", "required_capability_type"} <= set(
        requirement_record["required"]
    )


def test_assessment_migration_is_additive_and_idempotent(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    old_path = tmp_path / "legacy.db"
    connection = sqlite3.connect(old_path)
    connection.execute("CREATE TABLE legacy_state (id INTEGER PRIMARY KEY, value TEXT NOT NULL)")
    connection.execute("INSERT INTO legacy_state (value) VALUES ('preserved')")
    connection.execute(
        """
        CREATE TABLE scenario_assessments (
            assessment_id TEXT PRIMARY KEY,
            user_id INTEGER,
            model_id TEXT NOT NULL,
            scenario_spec TEXT NOT NULL,
            feasibility_assessment TEXT NOT NULL,
            created_at TEXT NOT NULL
        )
        """
    )
    connection.execute(
        """
        INSERT INTO scenario_assessments (
            assessment_id, user_id, model_id, scenario_spec,
            feasibility_assessment, created_at
        ) VALUES ('ASM-LEGACY', NULL, 'walker_s2', '{}', '{}', '2026-01-01T00:00:00+00:00')
        """
    )
    connection.execute(
        """
        CREATE TABLE capability_catalog_source_state (
            model_id TEXT PRIMARY KEY,
            changes_json TEXT NOT NULL DEFAULT '{}',
            current_source_files INTEGER NOT NULL DEFAULT 0,
            last_organized_manifest_files INTEGER NOT NULL DEFAULT 0,
            checked_at TEXT NOT NULL
        )
        """
    )
    connection.execute(
        """
        INSERT INTO capability_catalog_source_state (
            model_id, changes_json, current_source_files,
            last_organized_manifest_files, checked_at
        ) VALUES ('walker_s2', '{}', 17, 17, '2026-01-01T00:00:00+00:00')
        """
    )
    connection.commit()
    connection.close()

    monkeypatch.setattr(database, "DATABASE_PATH", old_path)
    database.initialize_database()
    database.initialize_database()
    connection = sqlite3.connect(old_path)
    try:
        assert connection.execute("SELECT value FROM legacy_state").fetchone()[0] == "preserved"
        tables = {row[0] for row in connection.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    finally:
        connection.close()
    assert "scenario_assessments" in tables
    assert "capability_draft_stubs" in tables
    assert "capability_catalog_jobs" in tables
    assert "capability_catalog_source_state" in tables
    legacy_source_state = database.get_capability_catalog_source_state("walker_s2")
    assert legacy_source_state is not None
    assert legacy_source_state["current_source_files"] == 17
    assert legacy_source_state["current_wiki_files"] is None
    assert legacy_source_state["last_organized_wiki_files"] is None
    assert legacy_source_state["wiki_changes"] is None
    connection = sqlite3.connect(old_path)
    try:
        assessment_columns = {
            row[1] for row in connection.execute("PRAGMA table_info(scenario_assessments)")
        }
        legacy_status = connection.execute(
            "SELECT analysis_status, updated_at FROM scenario_assessments "
            "WHERE assessment_id = 'ASM-LEGACY'"
        ).fetchone()
    finally:
        connection.close()
    assert {
        "conversation_id",
        "atomic_requirements",
        "capabilities",
        "scenario_text",
        "language",
        "analysis_status",
        "analysis_error",
        "updated_at",
    } <= assessment_columns
    assert legacy_status == ("completed", "2026-01-01T00:00:00+00:00")


def test_database_restart_marks_active_analysis_as_interrupted() -> None:
    database.create_scenario_analysis_job(
        assessment_id="ASM-RESTARTED",
        user_id=None,
        conversation_id="web:restart",
        model_id=database.get_allowed_teams()[0],
        scenario_text="Move boxes",
        language="en",
    )

    database.initialize_database()

    recovered = database.get_scenario_assessment("ASM-RESTARTED")
    assert recovered is not None
    assert recovered["analysis_status"] == "failed"
    assert "server restart" in recovered["analysis_error"]


def test_public_analysis_persists_and_exports_markdown_and_pdf(monkeypatch: pytest.MonkeyPatch) -> None:
    model_id = database.get_allowed_teams()[0]
    gateway.websocket = object()

    async def fake_command(message_type: str, **payload):
        assert message_type == "analyze_scenario"
        assert payload["model_id"] == model_id
        assert payload["language"] == "zh-CN"
        return {"status": "ok", "result": enforce_abstraction_hard_gate(_worker_payload())}

    monkeypatch.setattr(gateway, "command", fake_command)
    async def run_analysis() -> tuple[object, dict, object, dict]:
        response = await analyze_capability_match(
            AnalyzeScenarioRequest(
                scenario_text="Serve popcorn outdoors at 15 cups per minute",
                model_id=model_id,
                conversation_id="web:test",
                language="zh-CN",
            ),
            _request(),
        )
        response_data = json.loads(response.body)
        assessment_id = response_data["assessment_id"]
        active_response = await get_capability_match(assessment_id)
        active_data = json.loads(active_response.body)
        active_export = await export_capability_match(
            assessment_id=assessment_id,
            format="markdown",
            language="en",
        )
        await asyncio.gather(*list(_analysis_tasks.values()))
        completed_response = await get_capability_match(assessment_id)
        return response, active_data, active_export, json.loads(completed_response.body)

    response, active_data, active_export, completed_data = asyncio.run(
        run_analysis()
    )
    response_data = json.loads(response.body)
    assert response.status_code == 202, response_data
    assert active_data["analysis_status"] in {"queued", "processing"}
    assert active_export.status_code == 409
    assessment_id = response_data["assessment_id"]
    assert completed_data["analysis_status"] == "completed"
    assert completed_data["assessment"]["assessment_id"] == assessment_id
    saved = database.get_scenario_assessment(assessment_id)
    assert saved is not None
    assert saved["model_id"] == model_id
    assert saved["analysis_status"] == "completed"

    workbench = asyncio.run(capability_match_page(assessment_id))
    assert workbench.status_code == 200
    workbench_html = workbench.body.decode()
    assert "Scenario clarification and evidence-backed analysis" in workbench_html
    assert '<option value="zh-CN">简体中文</option>' in workbench_html
    assert "I want something else" in workbench_html
    assert "I don't know yet" in workbench_html
    assert 'id="drawer"' in workbench_html
    assert "textContent" in workbench_html
    assert "innerHTML" not in workbench_html

    ask_html = (
        Path(__file__).resolve().parents[1] / "ecs" / "app" / "templates" / "ask.html"
    ).read_text(encoding="utf-8")
    assert 'id="scenarioAssessment"' in ask_html
    assert 'href="/capability-match"' in ask_html
    assert 'href="/capability-match" hidden' in ask_html
    assert "monitorDemandAnalysis" not in ask_html
    assert "/api/capability-match/analyze" not in ask_html
    assert "demandMode" not in ask_html

    markdown = asyncio.run(
        export_capability_match(
            assessment_id=assessment_id,
            format="markdown",
            language="zh-CN",
        )
    )
    assert markdown.status_code == 200
    markdown_text = markdown.body.decode()
    assert "# 机器人场景可行性报告" in markdown_text
    assert "## 原子需求匹配矩阵" in markdown_text
    assert "Operational behavior evidence required" in markdown_text
    assert markdown.headers["content-disposition"].endswith('"feasibility_report.md"')

    pdf = asyncio.run(
        export_capability_match(
            assessment_id=assessment_id,
            format="pdf",
            language="zh-CN",
        )
    )
    assert pdf.status_code == 200
    assert pdf.body.startswith(b"%PDF-")
    assert pdf.headers["content-type"] == "application/pdf"


def test_admin_gap_analytics_and_stub_generator_require_admin_and_csrf(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    model_id = database.get_allowed_teams()[0]
    assessment_id = f"ASM-{uuid.uuid4().hex.upper()}"
    payload = enforce_abstraction_hard_gate(_worker_payload())
    database.create_scenario_assessment(
        assessment_id=assessment_id,
        user_id=None,
        conversation_id="web:test",
        model_id=model_id,
        scenario_spec=payload["scenario_spec"],
        atomic_requirements=payload["atomic_requirements"],
        capabilities=payload["capabilities"],
        feasibility_assessment={**payload["feasibility_assessment"], "assessment_id": assessment_id},
    )
    request, csrf = _admin_request()
    page = asyncio.run(admin_capabilities_page(request))
    assert page.status_code == 200
    analytics = asyncio.run(capability_gap_analytics(request))
    assert analytics.status_code == 200
    assert json.loads(analytics.body)["gaps"][0]["occurrence_count"] == 1

    with pytest.raises(Exception) as missing_csrf:
        asyncio.run(
            create_gap_stub(
                CreateDraftStubRequest(
                    assessment_id=assessment_id, requirement_id="REQ-FILL"
                ),
                request,
                x_csrf_token="",
            )
        )
    assert getattr(missing_csrf.value, "status_code", None) == 403

    created = asyncio.run(
        create_gap_stub(
            CreateDraftStubRequest(
                assessment_id=assessment_id, requirement_id="REQ-FILL"
            ),
            request,
            x_csrf_token=csrf,
        )
    )
    created_data = json.loads(created.body)
    assert created.status_code == 200, created_data
    assert created_data["stub"]["status"] == "draft"
    assert created_data["stub"]["details"]["evidence_status"] == "acquisition_required"
    assert database.list_audit_log(limit=1)[0]["action"] == "create_capability_draft_stub"

    duplicate = asyncio.run(
        create_gap_stub(
            CreateDraftStubRequest(
                assessment_id=assessment_id, requirement_id="REQ-FILL"
            ),
            request,
            x_csrf_token=csrf,
        )
    )
    assert duplicate.status_code == 200
    assert json.loads(duplicate.body)["stub"]["stub_id"] == created_data["stub"]["stub_id"]


def test_admin_catalog_start_and_source_change_snapshot_are_shared(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    model_id = capability_match_routes.CAPABILITY_CATALOG_SCOPE
    request, csrf = _admin_request()
    gateway.websocket = object()  # The API only needs the persistent Worker online signal here.
    started: list[tuple[str, str, str, str]] = []

    async def fake_command(message_type: str, **payload):
        assert message_type == "inspect_capability_source_changes"
        assert payload["model_id"] == model_id
        return {
            "status": "ok",
            "result": {
                "model_id": model_id,
                "current_source_files": 2,
                "last_organized_manifest_files": 1,
                "current_wiki_files": 7,
                "last_organized_wiki_files": 5,
                "baseline_exists": True,
                "last_scan_mode": "full",
                "catalog_revision": "rev-test",
                "changes": {
                    "baseline_exists": True,
                    "added": ["upload/new.md"],
                    "modified": [],
                    "deleted": [],
                    "counts": {"added": 1, "modified": 0, "deleted": 0, "total": 1},
                },
                "wiki_changes": {
                    "baseline_exists": True,
                    "added": ["entities/new.md"],
                    "modified": [],
                    "deleted": [],
                    "counts": {"added": 1, "modified": 0, "deleted": 0, "total": 1},
                },
            },
        }

    monkeypatch.setattr(gateway, "command", fake_command)
    monkeypatch.setattr(
        capability_match_routes,
        "_start_capability_catalog_job",
        lambda job_id, selected_model, snapshot_id, scan_mode: started.append(
            (job_id, selected_model, snapshot_id, scan_mode)
        ),
    )

    changes_response = asyncio.run(capability_source_changes(request))
    changes = json.loads(changes_response.body)
    assert changes_response.status_code == 200
    assert changes["changes"]["added"] == ["upload/new.md"]
    assert changes["current_wiki_files"] == 7
    assert changes["wiki_changes"]["added"] == ["entities/new.md"]
    saved_state = database.get_capability_catalog_source_state(model_id)
    assert saved_state["current_source_files"] == 2
    assert saved_state["current_wiki_files"] == 7
    assert saved_state["last_organized_wiki_files"] == 5
    assert saved_state["baseline_exists"] is True
    assert saved_state["catalog_revision"] == "rev-test"

    start_response = asyncio.run(
        start_capability_catalog_organization(
            OrganizeCapabilitiesRequest(scan_mode="incremental"),
            request,
            x_csrf_token=csrf,
        )
    )
    body = json.loads(start_response.body)
    assert start_response.status_code == 202
    assert body["job"]["status"] == "queued"
    assert body["job"]["scan_mode"] == "incremental"
    assert started[0][0] == body["job"]["job_id"]
    assert started[0][3] == "incremental"

    shared_response = asyncio.run(capability_gap_analytics(request))
    shared = json.loads(shared_response.body)
    assert shared["catalog_jobs"][0]["job_id"] == body["job"]["job_id"]
    job_response = asyncio.run(capability_catalog_job(body["job"]["job_id"], request))
    assert json.loads(job_response.body)["job"]["model_id"] == model_id
    assert database.list_audit_log(limit=1)[0]["action"] == "organize_atomic_capabilities"


def test_source_change_refresh_does_not_compete_with_active_catalog_scan(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    model_id = capability_match_routes.CAPABILITY_CATALOG_SCOPE
    request, _ = _admin_request()
    user_id = database.create_user_record(
        username="catalog-runner",
        email="catalog-runner@example.com",
        password_hash="hash",
        password_salt="salt",
        role="admin",
        teams="",
    )
    database.upsert_capability_catalog_source_state(
        model_id=model_id,
        changes={"added": [], "modified": [], "deleted": []},
        current_source_files=17,
        last_organized_manifest_files=17,
    )
    database.create_capability_catalog_job(
        job_id="CAT-ACTIVE",
        created_by=user_id,
        model_id=model_id,
        snapshot_id="SRC-ACTIVE",
        scan_mode="full",
    )
    gateway.websocket = object()

    async def unexpected_command(*args, **kwargs):
        raise AssertionError("source inspection must not enter the busy catalog queue")

    monkeypatch.setattr(gateway, "command", unexpected_command)
    response = asyncio.run(capability_source_changes(request))
    body = json.loads(response.body)

    assert response.status_code == 200
    assert body["stale"] is True
    assert body["stale_reason"] == "scan_in_progress"
    assert body["active_job_id"] == "CAT-ACTIVE"
    assert body["current_source_files"] == 17
    assert body["current_wiki_files"] is None


def test_admin_full_scan_is_repository_wide_and_disables_checkpoint_resume(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    model_id = capability_match_routes.CAPABILITY_CATALOG_SCOPE
    request, csrf = _admin_request()
    gateway.websocket = object()
    started: list[tuple[str, str, str, str]] = []
    monkeypatch.setattr(
        capability_match_routes,
        "_start_capability_catalog_job",
        lambda job_id, selected_model, snapshot_id, scan_mode: started.append(
            (job_id, selected_model, snapshot_id, scan_mode)
        ),
    )

    response = asyncio.run(
        start_capability_catalog_organization(
            OrganizeCapabilitiesRequest(
                scan_mode="full",
            ),
            request,
            x_csrf_token=csrf,
        )
    )
    body = json.loads(response.body)

    assert response.status_code == 202
    assert body["job"]["scan_mode"] == "full"
    assert started == [
        (
            body["job"]["job_id"],
            model_id,
            body["job"]["snapshot_id"],
            "full",
        )
    ]


def test_full_catalog_job_sends_repository_scope_and_disables_checkpoints(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    model_id = capability_match_routes.CAPABILITY_CATALOG_SCOPE
    user_id = database.create_user_record(
        username="force_catalog_admin",
        email="force_catalog_admin@example.com",
        password_hash="hash",
        password_salt="salt",
        role="admin",
        teams="",
    )
    database.create_capability_catalog_job(
        job_id="CAT-FULL",
        created_by=user_id,
        model_id=model_id,
        snapshot_id="WIKISET-FULL",
        scan_mode="full",
    )
    sent: list[tuple[str, dict]] = []

    async def fake_command(message_type: str, **payload):
        sent.append((message_type, payload))
        return {
            "status": "ok",
            "result": {
                "completion_status": "completed",
                "changes": {},
                "current_source_files": 0,
                "last_organized_manifest_files": 0,
            },
        }

    monkeypatch.setattr(gateway, "command", fake_command)

    asyncio.run(
        capability_match_routes._run_capability_catalog_job(
            "CAT-FULL",
            model_id,
            "WIKISET-FULL",
            "full",
        )
    )

    assert sent[0][0] == "organize_capability_catalog"
    assert sent[0][1]["scan_mode"] == "full"
    assert sent[0][1]["reuse_checkpoints"] is False
    assert sent[0][1]["model_id"] == "repository"
    assert set(sent[0][1]["known_robot_ids"]) >= {
        "tian_gong",
        "walker_s2",
        "walker_c1",
    }
    assert database.get_capability_catalog_job("CAT-FULL")["status"] == "completed"
